import React from 'react';
import './Footer.css';

function Footer() {
    return (
        <div className='footer'>
            <h2 className='footer-text'>Donate food, nourish hope</h2>
        </div>
    );
}

export default Footer;
